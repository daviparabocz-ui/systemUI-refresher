package com.davi.systemuirefresh

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import java.io.DataOutputStream

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshSystemUI()
        finish()
    }

    private fun refreshSystemUI() {
        try {
            val process = Runtime.getRuntime().exec("su")
            val os = DataOutputStream(process.outputStream)

            // Mata o processo do SystemUI; como é um processo persistente
            // declarado pelo framework, o system_server o reinicia sozinho.
            os.writeBytes("killall com.android.systemui\n")
            os.writeBytes("exit\n")
            os.flush()

            val exitCode = process.waitFor()
            if (exitCode == 0) {
                Toast.makeText(this, "SystemUI reiniciada", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Falha ao reiniciar (código $exitCode)", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Erro: acesso root (su) negado ou indisponível", Toast.LENGTH_LONG).show()
        }
    }
}
