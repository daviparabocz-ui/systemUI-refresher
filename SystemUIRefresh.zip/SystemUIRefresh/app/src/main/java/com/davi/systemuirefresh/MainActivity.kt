package com.davi.systemuirefresh

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import java.io.DataOutputStream

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnReiniciar).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.dialog_titulo)
                .setMessage(R.string.dialog_msg)
                .setPositiveButton(R.string.dialog_sim) { _, _ -> refreshSystemUI() }
                .setNegativeButton(R.string.dialog_nao, null)
                .show()
        }
    }

    private fun refreshSystemUI() {
        Thread {
            try {
                // Chamar "su" aqui, em foreground e sem finish() prematuro,
                // é o que dá tempo do Magisk mostrar o diálogo de permissão.
                val process = Runtime.getRuntime().exec("su")
                val os = DataOutputStream(process.outputStream)

                // Mata o processo do SystemUI; como é um processo persistente
                // declarado pelo framework, o system_server o reinicia sozinho.
                os.writeBytes("killall com.android.systemui\n")
                os.writeBytes("exit\n")
                os.flush()

                val exitCode = process.waitFor()
                runOnUiThread {
                    if (exitCode == 0) {
                        Toast.makeText(this, "SystemUI reiniciada", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Falha ao reiniciar (código $exitCode)", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Erro: acesso root (su) negado ou indisponível", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
